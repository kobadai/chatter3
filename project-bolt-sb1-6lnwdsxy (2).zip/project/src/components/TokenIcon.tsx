import React from 'react';

interface TokenIconProps {
  className?: string;
}

const TokenIcon: React.FC<TokenIconProps> = ({ className = "h-6 w-6" }) => {
  return (
    <img
      src="https://raw.githubusercontent.com/stackblitz/assets/master/packages/bolt/c3t-token.png"
      alt="C3T Token"
      className={className}
    />
  );
};

export default TokenIcon;